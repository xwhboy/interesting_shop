package com.dao;

/**
 * Created by ZK on 6/26/16.
 */
public interface PictureDAO {
}
